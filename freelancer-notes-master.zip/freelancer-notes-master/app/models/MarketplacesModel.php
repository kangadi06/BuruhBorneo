<?php
/**
 * Created by PhpStorm.
 * User: PCROY
 * Date: 23-Nov-14
 * Time: 1:22 AM
 */

class MarketplacesModel extends Eloquent{
    protected $table = 'marketplaces';
}